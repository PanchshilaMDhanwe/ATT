package basiccalls;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class Post_CreateUser {

	
	@Test 

	public void createUser() 

	{ 

	RestAssured.baseURI = "https://petstore.swagger.io/v2"; 

	 

	Response response = given() 

	 

	.body("{\r\n" 

	+ "  \"id\": 0,\r\n" 

	+ "  \"username\": \"restassureduser\",\r\n" 

	+ "  \"firstName\": \"automation\",\r\n" 

	+ "  \"lastName\": \"test\",\r\n" 

	+ "  \"email\": \"automation@test.com\",\r\n" 

	+ "  \"password\": \"Test@1234\",\r\n" 

	+ "  \"phone\": \"9876543212\",\r\n" 

	+ "  \"userStatus\": 0\r\n" 

	+ "}") 

	 

	.header("Content-Type", "application/json") 

	 

	.when() 

	 

	.post("user") 

	 

	.then() 

	 

	.extract() 

	 

	.response(); 

	 

	String strResponse = response.asPrettyString(); 
	System.out.println(strResponse);

	} 

	 

	
}
