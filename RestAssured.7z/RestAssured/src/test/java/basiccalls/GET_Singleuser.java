package basiccalls;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import junit.framework.Assert;

import static io.restassured.RestAssured.*;

public class GET_Singleuser {

	@Test
	public void fetchUser() {
		
		RestAssured.baseURI = "https://reqres.in";
		
		Response resp = given()
		
		.when()
		
		.get("/api/users/1")
		
		.then()
		
		.extract()
		
		.response();
		
		String strResp = resp.asPrettyString();
		System.out.println(strResp);
		
		
		int stsCode = resp.getStatusCode();
		System.out.println(stsCode);
		Assert.assertEquals(stsCode, 200);
		long TimeTaken =resp.getTime();
		System.out.println(TimeTaken);
		
	}
}
