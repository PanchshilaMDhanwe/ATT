package basiccalls;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class GetListOfUsers {

	
	@Test
	public void fetchingUserDetails()
	{
		RestAssured.baseURI = "https://reqres.in";
		
		Response resp = given() //Response is an interface
		
		.when()
		
		//.get("api/users?page=2")
		
		.get("api/users/2")
		
		.then()
		
		.extract()
		
		.response();
		
		System.out.println(resp);
		
		String stringResponse = resp.asPrettyString();
		
		System.out.println(stringResponse);
		
		int stsCode =resp.statusCode();
		System.out.println(stsCode);
	}
	
}
