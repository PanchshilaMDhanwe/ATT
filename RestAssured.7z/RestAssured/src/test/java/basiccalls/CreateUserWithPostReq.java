package basiccalls;

public class CreateUserWithPostReq {

}
